import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {

  pList = [
    {pId:101, pName:'Pepsi',pCategory:'Cold-Drink',pPrice:50},
    {pId:102, pName:'Coke',pCategory:'Cold-Drink',pPrice:50},
    {pId:103, pName:'Maggie',pCategory:'Fast-Food',pPrice:75},
    {pId:104, pName:'Appy',pCategory:'Cold-Drink',pPrice:50},
    {pId:105, pName:'Iphone',pCategory:'Electronics',pPrice:140000},
  ]


  addNewProduct(newProduct:any)
  {
    this.pList.push(newProduct);
    alert('Product Added Successfully');
  }


  constructor() { }
}
