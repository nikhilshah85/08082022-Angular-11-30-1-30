import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from 'src/app/services/productservice.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {


  _prodSER:ProductserviceService;
  constructor(_prodSERREF:ProductserviceService){
    this._prodSER = _prodSERREF;
   }

  ngOnInit(): void {
  }

}
