import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from 'src/app/services/productservice.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {


  _prodSER:ProductserviceService;
  
  constructor(_prodSERREF:ProductserviceService) {
    this._prodSER = _prodSERREF;
   }

  ngOnInit(): void {
  }

}
