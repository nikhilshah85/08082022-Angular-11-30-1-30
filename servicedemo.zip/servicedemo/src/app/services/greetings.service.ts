import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GreetingsService {

    discountRate = 15;
    cartValue =0;

    addToCart(amount:number)
    {
      this.cartValue = this.cartValue + amount;
    }


    greetings()
    {
      return 'Hello and Welcome to Angular Service world';
    }

    calculateDiscount(amount:number,copoun:string)
    {
      if(copoun == 'AUG15')
      {
       return  amount * 50 / 100;
      }
      if(copoun == 'AUG22')
      {
        return amount * 25 / 100;
      }
      if(copoun == 'SPECIAL75')
      {
        return amount * 75 /100;
      }
      return 0;
    }



  constructor() { }
}
