import { Component } from '@angular/core';
import { GreetingsService } from './services/greetings.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'servicedemo';

    _greetinSER:GreetingsService;
    constructor(_greetingSERREF:GreetingsService)
    {
        this._greetinSER = _greetingSERREF;
    }


}
