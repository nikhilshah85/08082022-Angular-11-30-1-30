import { Component, OnInit } from '@angular/core';
import { GreetingsService } from 'src/app/services/greetings.service';

@Component({
  selector: 'app-femaleproducts',
  templateUrl: './femaleproducts.component.html',
  styleUrls: ['./femaleproducts.component.css']
})
export class FemaleproductsComponent implements OnInit {



  _greetinSER:GreetingsService;

  constructor(_greetingSERREF:GreetingsService) {
    this._greetinSER = _greetingSERREF;
   }

  ngOnInit(): void {
  }

}
