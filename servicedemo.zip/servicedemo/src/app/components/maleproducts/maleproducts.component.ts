import { Component, OnInit } from '@angular/core';
import { GreetingsService } from 'src/app/services/greetings.service';

@Component({
  selector: 'app-maleproducts',
  templateUrl: './maleproducts.component.html',
  styleUrls: ['./maleproducts.component.css']
})
export class MaleproductsComponent implements OnInit {

  _greetinSER:GreetingsService;

  //service is a class, to access any method or propery of that class, we need to create a new objecct
  //but, instead, object will created and shared between components by Angular
  constructor(_greetingSERREF:GreetingsService)
  {
    this._greetinSER = _greetingSERREF;
   }

  ngOnInit(): void {
  }

}
