import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  componentName ="Products";
  totalProducts = 20;
  todaysDate = new Date();




  constructor() { }

  ngOnInit(): void {
  }

}
