import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 

  appName = "Angular Components training";
  trainer = "Nikhil Shah";
  attendees = 38;

  greetings()
  {
    alert('Hello and Welcome to Angular Development Training');
  }


}
