import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stocks',
  templateUrl: './stocks.component.html',
  styleUrls: ['./stocks.component.css']
})
export class StocksComponent implements OnInit {


    stockInfo= {
      stockId:101,
      stockName:'Reliance',
      stockCategory:'Petro Chemicals',
      stockPurchasePrice:1200,
      stockCurrentPrice:2600,
      stockQty:50,
      stockPromoters:['Mukesh','Nita','Anil','Ananth']

    }


  constructor() { }

  ngOnInit(): void {
  }

}
