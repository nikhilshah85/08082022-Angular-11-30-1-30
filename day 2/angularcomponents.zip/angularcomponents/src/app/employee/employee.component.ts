import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  empNo:number = 101;
  empName:string = "Nikhil";
  empDesignation:string = "Consultant";
  empSalary:number  = 2000;
  empIsPermenant:boolean = true;

  empSkills:string[] = ['Angular','.Net','Azure','SQL Server','MSBI','Databricks','Azure Synapse','React'];



  constructor() { }

  ngOnInit(): void {
  }

}
