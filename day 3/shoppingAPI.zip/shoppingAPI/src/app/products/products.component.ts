import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {


  productList = [
    {pId:101, pName:'Pepsi',pCategory:'Cold-Drink',pPrice:50,pAvailableQty:50, pDiscount:10,pIsInstock:true},
    {pId:102, pName:'Coke',pCategory:'Cold-Drink',pPrice:45,pAvailableQty:50, pDiscount:15,pIsInstock:true},
    {pId:103, pName:'Maggie',pCategory:'Fast-Food',pPrice:150,pAvailableQty:50, pDiscount:18,pIsInstock:false},
    {pId:104, pName:'Fossil',pCategory:'Electronic',pPrice:18000,pAvailableQty:50, pDiscount:2,pIsInstock:true},
    {pId:105, pName:'Axe',pCategory:'Accessory',pPrice:250,pAvailableQty:50, pDiscount:15,pIsInstock:true},
    {pId:106, pName:'Pears',pCategory:'Accessory',pPrice:125,pAvailableQty:50, pDiscount:10,pIsInstock:true},
    {pId:107, pName:'Close-Up',pCategory:'Accessory',pPrice:95,pAvailableQty:50, pDiscount:8,pIsInstock:false},
    {pId:108, pName:'Tetley',pCategory:'Hot-Drink',pPrice:580,pAvailableQty:50, pDiscount:12,pIsInstock:true},
    {pId:109, pName:'Mocha',pCategory:'Hot-Drink',pPrice:240,pAvailableQty:50, pDiscount:0,pIsInstock:true},
  ]


  addProduct(newProduct:any){
    console.log(newProduct);
    this.productList.push({pId:newProduct.pId, 
                           pName:newProduct.pName,
                           pCategory:newProduct.pCategory,
                           pPrice:newProduct.pPrice,
                           pAvailableQty:newProduct.pAvailableQty, 
                           pDiscount:newProduct.pDiscount,
                           pIsInstock:newProduct.pIsInstock});
  }


  constructor() { }

  ngOnInit(): void {
  }

}
