import { Injectable } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService implements CanActivate{

  private _isLoggedIn:boolean = false;
  checkUserLogin(userName:string, password:string):void
  {
    //make a web api call here, usering HttpClient, send the data to webapi and web api will return the resutl
    if (userName == 'Nikhil' && password =='Pass@1234') {
      alert('Weclome');
      this._isLoggedIn = true;
      
    }
    else
    {
      alert('Invalid Credentials');
      this._isLoggedIn = false;
    }
  }

  constructor() { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this._isLoggedIn;
  }
}
