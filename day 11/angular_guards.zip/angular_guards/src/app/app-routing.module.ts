import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './components/about/about.component';
import { AddproductComponent } from './components/addproduct/addproduct.component';
import { CartComponent } from './components/cart/cart.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { OrdersComponent } from './components/orders/orders.component';
import { ProductsComponent } from './components/products/products.component';
import { FemaleproductsComponent } from './components/ProductsTypes/femaleproducts/femaleproducts.component';
import { KidsproductsComponent } from './components/ProductsTypes/kidsproducts/kidsproducts.component';
import { MaleproductsComponent } from './components/ProductsTypes/maleproducts/maleproducts.component';
import { OffersproductsComponent } from './components/ProductsTypes/offersproducts/offersproducts.component';
import { AuthserviceService } from './services/authservice.service';

const routes: Routes = [
  {path:'',component:HomeComponent, pathMatch:'full'},
  { path:'home',component:HomeComponent },
  { path:'about',component:AboutComponent },
  { path:'products',component:ProductsComponent, children:[
      {path:'male',component:MaleproductsComponent},
      {path:'female',component:FemaleproductsComponent},
      {path:'kids',component:KidsproductsComponent},
      {path:'offers',component:OffersproductsComponent},
  ] },
  { path:'addproducts',component:AddproductComponent, canActivate:[AuthserviceService] },
  { path:'orders',component:OrdersComponent,canActivate:[AuthserviceService]  },
  { path:'cart',component:CartComponent,canActivate:[AuthserviceService]  },
  { path:'login',component:LoginComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
