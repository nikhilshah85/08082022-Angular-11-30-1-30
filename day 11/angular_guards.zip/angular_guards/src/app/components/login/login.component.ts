import { Component, OnInit } from '@angular/core';
import { AuthserviceService } from 'src/app/services/authservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  _authService:AuthserviceService;

  constructor(_authServiceREF:AuthserviceService){
    this._authService = _authServiceREF;
   }


  ngOnInit(): void {
  }

}
