import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kidsproducts',
  templateUrl: './kidsproducts.component.html',
  styleUrls: ['./kidsproducts.component.css']
})
export class KidsproductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
