import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-femaleproducts',
  templateUrl: './femaleproducts.component.html',
  styleUrls: ['./femaleproducts.component.css']
})
export class FemaleproductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
