import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offersproducts',
  templateUrl: './offersproducts.component.html',
  styleUrls: ['./offersproducts.component.css']
})
export class OffersproductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
