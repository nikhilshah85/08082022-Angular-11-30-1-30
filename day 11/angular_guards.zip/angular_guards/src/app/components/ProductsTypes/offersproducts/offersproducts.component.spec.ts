import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OffersproductsComponent } from './offersproducts.component';

describe('OffersproductsComponent', () => {
  let component: OffersproductsComponent;
  let fixture: ComponentFixture<OffersproductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OffersproductsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OffersproductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
