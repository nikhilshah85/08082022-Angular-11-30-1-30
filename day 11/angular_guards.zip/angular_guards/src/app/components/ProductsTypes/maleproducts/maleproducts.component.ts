import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maleproducts',
  templateUrl: './maleproducts.component.html',
  styleUrls: ['./maleproducts.component.css']
})
export class MaleproductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
