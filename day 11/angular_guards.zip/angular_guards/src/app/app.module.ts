import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { ProductsComponent } from './components/products/products.component';
import { CartComponent } from './components/cart/cart.component';
import { OrdersComponent } from './components/orders/orders.component';
import { AddproductComponent } from './components/addproduct/addproduct.component';
import { LoginComponent } from './components/login/login.component';
import { MaleproductsComponent } from './components/ProductsTypes/maleproducts/maleproducts.component';
import { FemaleproductsComponent } from './components/ProductsTypes/femaleproducts/femaleproducts.component';
import { KidsproductsComponent } from './components/ProductsTypes/kidsproducts/kidsproducts.component';
import { OffersproductsComponent } from './components/ProductsTypes/offersproducts/offersproducts.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ProductsComponent,
    CartComponent,
    OrdersComponent,
    AddproductComponent,
    LoginComponent,
    MaleproductsComponent,
    FemaleproductsComponent,
    KidsproductsComponent,
    OffersproductsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
