import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stockportfolio',
  templateUrl: './stockportfolio.component.html',
  styleUrls: ['./stockportfolio.component.css']
})
export class StockportfolioComponent implements OnInit {



  totalInvestMent = 0;
  currentValue = 0;

  calculateTotalInvestMent()
  {
    for(var i=0;i<this.stockPortfolio.length;i++)
    {
      this.totalInvestMent = this.totalInvestMent + (this.stockPortfolio[i].stockPurchase * this.stockPortfolio[i].qty)
      this.currentValue = this.currentValue + (this.stockPortfolio[i].stockCurrent * this.stockPortfolio[i].qty)
    }
  }


  stockPortfolio  =[
    {stockId:101, stockName:'Reliance', stockCategory:'Petro',stockPurchase:10,stockCurrent:15,qty:10},
    {stockId:102, stockName:'Jet', stockCategory:'Petro',stockPurchase:10,stockCurrent:8,qty:10},
    {stockId:103, stockName:'Ashok', stockCategory:'Petro',stockPurchase:10,stockCurrent:12,qty:10},
    {stockId:104, stockName:'HUL', stockCategory:'Petro',stockPurchase:10,stockCurrent:2,qty:10},
    {stockId:105, stockName:'Maruti', stockCategory:'Petro',stockPurchase:10,stockCurrent:8,qty:10},
    {stockId:106, stockName:'Bajaj', stockCategory:'Petro',stockPurchase:10,stockCurrent:6,qty:10},
    {stockId:107, stockName:'TCS', stockCategory:'Petro',stockPurchase:10,stockCurrent:25,qty:20},
    {stockId:108, stockName:'TATA Motors', stockCategory:'Petro',stockPurchase:10,stockCurrent:40,qty:10},
    {stockId:109, stockName:'Infy', stockCategory:'Petro',stockPurchase:10,stockCurrent:11,qty:10},
    {stockId:110, stockName:'Jubliant', stockCategory:'Petro',stockPurchase:10,stockCurrent:9,qty:10},

  ]





  constructor() { }

  ngOnInit(): void {
  }

}
