import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'stocksuggession'
})
export class StocksuggessionPipe implements PipeTransform {

 
  transform(value: any, purchasePrice:number,currentPrice:number) {
    
    if( (currentPrice - purchasePrice) > (purchasePrice * 15 / 100) )
    {
      return 'Sell';
    }
    if((purchasePrice - currentPrice) > (purchasePrice * 20 /100))
    {
      return 'Add More'
    }
    return 'Hold';


  }


}
