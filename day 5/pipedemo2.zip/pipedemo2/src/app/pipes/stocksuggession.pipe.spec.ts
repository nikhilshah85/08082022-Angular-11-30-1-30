import { StocksuggessionPipe } from './stocksuggession.pipe';

describe('StocksuggessionPipe', () => {
  it('create an instance', () => {
    const pipe = new StocksuggessionPipe();
    expect(pipe).toBeTruthy();
  });
});
