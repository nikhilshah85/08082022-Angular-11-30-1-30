import { ProfitlossPipe } from './profitloss.pipe';

describe('ProfitlossPipe', () => {
  it('create an instance', () => {
    const pipe = new ProfitlossPipe();
    expect(pipe).toBeTruthy();
  });
});
