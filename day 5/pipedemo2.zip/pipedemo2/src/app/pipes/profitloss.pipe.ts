import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'profitloss'
})
export class ProfitlossPipe implements PipeTransform {

  transform(value: any, purchasePrice:number,currentPrice:number):string {
    
    if(purchasePrice < currentPrice)
    {
      return 'Profit';
    }
    else if (purchasePrice > currentPrice)
    {
      return 'Loss';
    }
    else 
    return '-'
  }

}
