import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { StockportfolioComponent } from './components/stockportfolio/stockportfolio.component';
import { ProfitlossPipe } from './pipes/profitloss.pipe';
import { StocksuggessionPipe } from './pipes/stocksuggession.pipe';

@NgModule({
  declarations: [
    AppComponent,
    StockportfolioComponent,
    ProfitlossPipe,
    StocksuggessionPipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
