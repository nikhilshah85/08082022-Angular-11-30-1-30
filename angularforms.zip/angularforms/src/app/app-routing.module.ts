import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddproductComponent } from './components/addproduct/addproduct.component';
import { ViewproductsComponent } from './components/viewproducts/viewproducts.component';

const routes: Routes = [
  {path:'',component:ViewproductsComponent},
  {path:'products',component:ViewproductsComponent},
  {path:'products/add',component:AddproductComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
