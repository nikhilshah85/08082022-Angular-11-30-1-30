import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-viewproducts',
  templateUrl: './viewproducts.component.html',
  styleUrls: ['./viewproducts.component.css']
})
export class ViewproductsComponent implements OnInit {

  _productSer:ProductsService;

  
  constructor(_productSerREF:ProductsService)
  {
    this._productSer  = _productSerREF;
  }

  ngOnInit(): void {
  }

}
