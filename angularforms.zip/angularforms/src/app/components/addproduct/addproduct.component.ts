import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
  _productSer:ProductsService;

  
  constructor(_productSerREF:ProductsService)
  {
    this._productSer  = _productSerREF;
  }


  ngOnInit(): void {
  }

}
