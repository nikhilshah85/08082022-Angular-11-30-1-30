import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {


  private productsService=[
    {pId:101, pName:'Pepsi', pCategory:'Cold-Drinks',pPrice:50, pIsInStock:true},
    {pId:102, pName:'Maggies', pCategory:'Fast-Food',pPrice:75, pIsInStock:true},
    {pId:103, pName:'IPhone', pCategory:'Electronics',pPrice:50, pIsInStock:true},
  ]
  productCategories =['Cold-Drinks','Fast-Food','Electronics']

  getAllProducts()
  {
    return this.productsService;
  }

  addNewProduct(newProdct:any)
  {
    this.productsService.push(newProdct);
  }

  deleteProduct(pid:any)
  {    
    this.productsService.splice(0,pid);  
  }

  // updateProduct(product:any)
  // {
  //   var p = 
  // }

  constructor() { }
}
